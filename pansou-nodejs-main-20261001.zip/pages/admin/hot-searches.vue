<template><AdminHotSearchPage /></template>
