<template>
  <div class="source-app" :data-ready="clientReady ? 'true' : 'false'">
    <AdminAccessGate v-if="adminChecking || adminLocked" :checking="adminChecking" :authenticated="adminAuthenticated"
      :error="authError" title="进入管理后台" @authenticated="checkAdminSession" />
    <template v-else>
      <aside class="console-sidebar">
        <NuxtLink to="/" class="console-brand"><span class="brand-symbol">
            <ConsoleIcon name="box" :size="22" />
          </span>PanHub <span class="brand-tag">CONSOLE</span></NuxtLink>
        <nav aria-label="后台导航">
          <NuxtLink to="/admin/monitor" :class="['console-nav-link', { active: view === 'monitor' }]">
            <ConsoleIcon name="activity" />运行监控
          </NuxtLink>
          <NuxtLink to="/admin/sources" :class="['console-nav-link', { active: view === 'sources' }]">
            <ConsoleIcon name="box" />来源管理
          </NuxtLink>
          <NuxtLink to="/admin/proxies" :class="['console-nav-link', { active: (view as string) === 'proxies' }]">
            <ConsoleIcon name="globe" />代理节点
          </NuxtLink>
          <NuxtLink to="/admin/resources" :class="['console-nav-link', { active: (view as string) === 'resources' }]">
            <ConsoleIcon name="box" />网盘资源
          </NuxtLink>
          <NuxtLink to="/admin/hot-searches" class="console-nav-link">
            <ConsoleIcon name="search" />热门搜索
          </NuxtLink>
          <NuxtLink to="/admin/users" class="console-nav-link">
            <ConsoleIcon name="user" />用户管理
          </NuxtLink>
          <NuxtLink to="/admin/logs" class="console-nav-link">
            <ConsoleIcon name="activity" />搜索日志
          </NuxtLink>
          <NuxtLink to="/admin/policies" class="console-nav-link">
            <ConsoleIcon name="sliders" />系统设置
          </NuxtLink>
        </nav>
      </aside>

      <div class="console-body">
        <header class="console-topbar">
          <div class="breadcrumbs">
            <ConsoleIcon name="grid" :size="16" /><span>管理后台</span>
            <ConsoleIcon name="chevron" :size="13" /><strong>{{
              viewTitle
              }}</strong>
          </div>
          <div class="topbar-right">
            <button class="session-button" type="button" @click="lockAdmin">
              <span>退出后台</span>
              <ConsoleIcon name="logout" :size="15" />
            </button>
          </div>
        </header>
        <main class="console-main" :class="{ 'console-main-sources': view === 'sources' }">
          <div v-if="storageError" class="notice error-notice" role="alert">
            <ConsoleIcon name="info" />{{ storageError }}
          </div>

          <template v-if="view === 'sources'">
            <section class="sources-panel directory-panel" aria-label="来源管理目录">
              <div class="source-toolbar directory-toolbar" aria-label="来源查询与操作">
                <label class="source-search">
                  <ConsoleIcon name="search" :size="17" /><input v-model="search" type="search" aria-label="搜索来源名称或地址"
                    placeholder="搜索来源名称、地址或标签…" />
                </label>
                <button class="button primary directory-add-button" type="button" @click="openEditor()">
                  <ConsoleIcon name="plus" :size="15" />新增来源
                </button>
              </div>
              <div class="table-scroll">
                <table class="source-table directory-table admin-data-table">
                  <thead>
                    <tr>
                      <th class="source-index-column">序号</th>
                      <th>来源</th>
                      <th>状态</th>
                      <th>优先级</th>
                      <th>请求地址</th>
                      <th>操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(source, sourceIndex) in filteredSources" :key="source.id">
                      <td class="source-index-cell" data-label="序号">{{ sourceIndex + 1 }}</td>
                      <td class="source-summary-cell" data-label="来源">
                        <div class="source-identity">
                          <span class="source-avatar" :style="{ '--source-color': sourceColor(source) }">{{ sourceInitials(source)
                            }}</span>
                          <div class="source-text">
                            <div class="source-name">{{ source.name }}</div>
                            <div v-if="source.description" class="source-description">{{ source.description }}</div>
                          </div>
                        </div>
                      </td>
                      <td class="source-status-cell" data-label="状态">
                        <div class="source-state-tags">
                          <span class="source-state-tag" :class="source.enabled === false ? 'disabled' : 'enabled'">
                            {{ source.enabled === false ? '已停用' : '已启用' }}
                          </span>
                          <span class="source-state-tag" :class="circuitStateClass(source.id)">
                            {{ circuitStateLabel(source.id) }}
                          </span>
                        </div>
                      </td>
                      <td class="source-priority-cell" data-label="优先级">
                        <span class="source-priority-badge">{{ source.priority ?? 0 }}</span>
                      </td>
                      <td class="source-endpoint-cell" data-label="请求地址">
                        <a class="source-endpoint mono" :href="buildSourceCatalogUrl(source)" target="_blank"
                          rel="noopener noreferrer" :title="sourceCatalogLinkTitle(source)"
                          :aria-label="`在新标签打开 ${source.name} 的默认请求地址`">
                          <span class="source-endpoint-text">{{ displayUrl(buildSourceCatalogUrl(source))
                            }}</span>
                          <ConsoleIcon name="external" :size="13" />
                        </a>
                      </td>
                      <td class="action-column" data-label="操作">
                        <div class="row-actions">
                          <button class="row-action-button" :class="{ 'danger-action': source.enabled !== false }" type="button"
                            :aria-label="`${source.enabled === false ? '启用' : '停用'} ${source.name}`"
                            :disabled="!!runningId || !!sourceToggleId"
                            :title="source.enabled === false ? '重新加入搜索来源' : '从搜索来源中停用，配置保留'"
                            @click="toggleSource(source)">
                            {{ source.enabled === false ? '启用' : '停用' }}
                          </button>
                          <button class="row-action-button" type="button" :aria-label="`查看 ${source.name} 详情`" title="详情"
                            @click="openDetail(source)">
                            详情
                          </button>
                          <button class="row-action-button" type="button" :aria-label="`测试 ${source.name}`" title="测试"
                            :disabled="!!runningId" @click="openDebug(source)">
                            测试
                          </button>
                          <button class="row-action-button" type="button" :aria-label="`修改 ${source.name}`" title="修改"
                            @click="openEditor(source)">
                            编辑
                          </button>
                          <button class="row-action-button danger-action" type="button" :aria-label="`删除 ${source.name}`"
                            title="删除" :disabled="!!runningId || !!sourceToggleId" @click="requestDeleteSource(source)">
                            删除
                          </button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div v-if="!filteredSources.length" class="empty-sources">
                  <ConsoleIcon name="search" :size="28" />
                  <h3>没有匹配的来源</h3>
                  <p>修改关键词。</p><button class="button secondary small" type="button"
                    @click="search = ''">重置筛选</button>
                </div>
              </div>
              <footer class="table-footer"><span><span class="status-dot neutral"></span>{{ filteredSources.length }} /
                  {{ sources.length }} 个来源</span></footer>
            </section>
          </template>
          <MonitorPanel v-else-if="view === 'monitor'" @unauthorized="adminLocked = true"
            @test-source="testSourceById" />
        </main>
      </div>
    </template>
    <SourceDetailDrawer v-if="detailDrawerOpen && selected" :source="selected" :running="!!runningId"
      @close="detailDrawerOpen = false" @edit="openEditor(selected)"
      @debug="openDebug(selected)" @delete="requestDeleteSource(selected)" />
    <SourceDebugDialog v-if="debugDialogOpen && selected" :source="selected" :report="selectedReport"
      :keyword="keyword" :running="!!runningId" @close="debugDialogOpen = false" @send="testSource(selected)"
      @update:keyword="keyword = $event" />
    <SourceEditor v-if="!adminLocked && editorOpen" :source="editingSource" @close="editorOpen = false"
      @save="saveSource" />
    <div v-if="notice" class="console-toast" role="status">
      <ConsoleIcon name="info" :size="17" />{{ notice }}
    </div>
  </div>
</template>

<script setup lang="ts">
import AdminAccessGate from "../../components/admin/AdminAccessGate.vue";
import ConsoleIcon from "../../components/sources/ConsoleIcon.vue";
import MonitorPanel from "../../components/monitor/MonitorPanel.vue";
import SourceEditor from "../../components/sources/SourceEditor.vue";
import SourceDetailDrawer from "../../components/sources/SourceDetailDrawer.vue";
import SourceDebugDialog from "../../components/sources/SourceDebugDialog.vue";
import type { SourceDefinition, SourceProbe } from "../../types/source";
import { buildSourceCatalogUrl } from "../../utils/sourceDebugUrl";
const auth = useAuth();
useHead({
  title: "管理后台",
  meta: [
    { name: "robots", content: "noindex, nofollow" },
    {
      name: "viewport",
      content: "width=device-width, initial-scale=1, viewport-fit=cover",
    },
  ],
});
const clientReady = ref(false);
const configuredSources = ref<SourceDefinition[]>([]);
type SourceCircuitState = "closed" | "open" | "half-open";
const sourceCircuitStates = ref<Record<string, SourceCircuitState>>({});
const reports = ref<Record<string, SourceProbe>>({});
// The unified catalog is the only source directory. Transform functions are source configuration, not separate sources.
const sources = configuredSources;
const selectedId = ref("");
const defaultUnifiedSource: SourceDefinition = {
  id: "",
  name: "",
  description: "",
  url: "https://example.invalid",
  method: "GET",
  format: "json",
  priority: 0,
  transform: "",
  enabled: false,
};
const selected = computed<SourceDefinition>(
  () =>
    sources.value.find((s) => s.id === selectedId.value) ||
    sources.value[0] ||
    defaultUnifiedSource,
);
const selectedReport = computed(() => selected.value ? reports.value[selected.value.id] : undefined);
const route = useRoute();
type ConsoleView = "sources" | "monitor";
const rawRouteView = Array.isArray(route.params.view) ? route.params.view[0] : route.params.view;
if (!rawRouteView || !["sources", "monitor"].includes(String(rawRouteView))) {
  await navigateTo({ path: "/admin/sources", query: route.query }, { replace: true });
}
const view = computed<ConsoleView>(() => {
  const routeView = Array.isArray(route.params.view) ? route.params.view[0] : route.params.view;
  return routeView === "monitor" ? routeView : "sources";
});
const viewTitle = computed(
  () =>
    ({
      sources: "来源管理",
      monitor: "运行监控",
    } as Record<ConsoleView, string>)[view.value],
);
const search = ref("");
const runningId = ref("");
const keyword = ref("三体");
const editorOpen = ref(false);
const editingSource = ref<SourceDefinition | null>(null);
const detailDrawerOpen = ref(false);
const debugDialogOpen = ref(false);
const storageError = ref("");
const adminChecking = ref(true);
const adminAuthenticated = ref(false);
const adminLocked = ref(true);
const authError = ref("");
const sourceToggleId = ref("");
const notice = ref("");
useHead({ title: () => viewTitle.value });
let noticeTimer: ReturnType<typeof setTimeout>;
const SOURCE_COLORS = ["#4085b8", "#5b67c7", "#0f766e", "#b45309", "#9d174d", "#6d28d9"];
function sourceInitials(source: SourceDefinition): string {
  const name = source.name.trim();
  return name ? Array.from(name)[0]!.toUpperCase() : "S";
}
function sourceColor(source: SourceDefinition): string {
  let hash = 0;
  for (const char of source.id || source.name) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return SOURCE_COLORS[hash % SOURCE_COLORS.length]!;
}
function circuitStateLabel(sourceId: string): string {
  const state = sourceCircuitStates.value[sourceId];
  return state === "open" ? "已熔断" : state === "half-open" ? "半开" : "未熔断";
}
function circuitStateClass(sourceId: string): string {
  const state = sourceCircuitStates.value[sourceId];
  return state === "open" ? "circuit-open" : state === "half-open" ? "circuit-half-open" : "circuit-closed";
}

const filteredSources = computed(() =>
  sources.value.filter((s) => {
    const haystack = `${s.id} ${s.name} ${s.url} ${s.description}`.toLowerCase();
    return haystack.includes(search.value.trim().toLowerCase());
  }),
);
function apiErrorMessage(error: any): string {
  const code = error?.statusCode || error?.response?.status;
  if (code === 401) return "请先登录管理员账号。";
  if (code === 403) return "当前账号没有管理员权限。";
  if (code === 429) return "尝试次数过多，请稍后再试。";
  return error?.data?.statusMessage || error?.message || "服务端操作失败。";
}

async function loadSourceCatalog() {
  try {
    const response = await $fetch<{ data?: SourceDefinition[] }>("/api/settings/sources");
    configuredSources.value = response.data ?? [];
    storageError.value = "";
    if (!sources.value.some((source) => source.id === selectedId.value)) selectedId.value = sources.value[0]?.id || "";
  } catch (error: any) {
    configuredSources.value = [];
    if ([401, 403].includes(error?.statusCode || error?.response?.status)) {
      adminAuthenticated.value = false;
      adminLocked.value = true;
      detailDrawerOpen.value = false;
      debugDialogOpen.value = false;
    }
    storageError.value = apiErrorMessage(error);
  }
}
async function checkAdminSession() {
  adminChecking.value = true;
  authError.value = "";
  try {
    const status = await $fetch<{ authenticated: boolean; user: { role?: string } | null }>(
      "/api/account/session",
      { credentials: "include", cache: "no-store", retry: 0 },
    );
    adminAuthenticated.value = status.authenticated;
    adminLocked.value = !(status.authenticated && status.user?.role === "admin");
    if (!adminLocked.value) await loadSourceCatalog();
  } catch (error: any) {
    adminAuthenticated.value = false;
    adminLocked.value = true;
    authError.value = apiErrorMessage(error);
  } finally {
    adminChecking.value = false;
  }
}
async function lockAdmin() {
  try {
    await auth.logout();
  } finally {
    configuredSources.value = [];
    reports.value = {};
    editorOpen.value = false;
    detailDrawerOpen.value = false;
    debugDialogOpen.value = false;
    adminAuthenticated.value = false;
    adminLocked.value = true;
    authError.value = "";
    await navigateTo("/");
  }
}
const SENSITIVE_KEY = /(?:authorization|cookie|token|api[-_]?key|secret|password|passwd|credential|signature)/i;
function redactUrl(url: string) {
  try {
    const parsed = new URL(url);
    for (const key of [...parsed.searchParams.keys()]) {
      if (SENSITIVE_KEY.test(key)) parsed.searchParams.set(key, "[REDACTED]");
    }
    return parsed.toString();
  } catch {
    return url;
  }
}
function displayUrl(url: string) {
  const safeUrl = redactUrl(url).replace(/^https?:\/\//, "");
  try {
    return decodeURI(safeUrl);
  } catch {
    return safeUrl;
  }
}
function sourceCatalogLinkTitle(source: SourceDefinition): string {
  return `在新标签打开 ${source.name} 的默认请求地址\n${buildSourceCatalogUrl(source)}`;
}
function notify(message: string) {
  notice.value = message;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => (notice.value = ""), 4000);
}
onMounted(async () => {
  clientReady.value = true;
  if (adminChecking.value) await checkAdminSession();
  else if (!adminLocked.value) await loadSourceCatalog();
  if (adminLocked.value) {
    return;
  }
  await loadSourceHealth();
});
function openDetail(source: SourceDefinition) {
  selectedId.value = source.id;
  debugDialogOpen.value = false;
  detailDrawerOpen.value = true;
}
function openDebug(source: SourceDefinition) {
  selectedId.value = source.id;
  detailDrawerOpen.value = false;
  debugDialogOpen.value = true;
}
function focusChannelSource(channel: string) {
  const normalized = String(channel || "").replace(/^@/, "").toLowerCase();
  const source = sources.value.find((item) => item.id === normalized);
  if (source) openDebug(source);
  else notify(`未找到频道来源 @${normalized} 的配置。`);
}
function testSourceById(id: string) {
  const source = sources.value.find((item) => item.id === id);
  if (source) openDebug(source);
  else notify(`未找到资源源 ${id}。`);
}

function focusSource(id: string) {
  const source = sources.value.find((item) => item.id === id);
  if (source) openDetail(source);
}
function openEditor(source: SourceDefinition | null = null) {
  detailDrawerOpen.value = false;
  editingSource.value = source;
  editorOpen.value = true;
}
async function saveSource(source: SourceDefinition) {
  try {
    // All sources are catalog configuration now. The page no longer creates a
    // second "draft source" representation for a new source; saving is the
    // activation boundary and the next request reads the SQLite row directly.
    await $fetch("/api/settings/sources", {
      method: "PUT",
      body: { source },
    });
    await loadSourceCatalog();
    notify("来源配置已保存，下一次请求立即生效。");
  } catch (error: any) {
    notify(apiErrorMessage(error));
    return;
  }
  selectedId.value = source.id;
  search.value = "";
}

async function toggleSource(source: SourceDefinition) {
  if (sourceToggleId.value || runningId.value) return;
  const enabled = source.enabled === false;
  sourceToggleId.value = source.id;
  try {
    await $fetch(`/api/settings/sources/${encodeURIComponent(source.id)}/${enabled ? "enable" : "disable"}`, {
      method: "POST",
    });
    await Promise.all([loadSourceCatalog(), loadSourceHealth()]);
    notify(`${source.name} 已${enabled ? "启用" : "停用"}，下一次请求立即生效。`);
  } catch (error: any) {
    notify(apiErrorMessage(error));
  } finally {
    sourceToggleId.value = "";
  }
}
async function loadSourceHealth() {
  try {
    const response = await $fetch<{ data?: { sources?: Array<{ id?: string; health?: { circuitState?: SourceCircuitState | null } | null }> } }>(
      "/api/monitor",
      { cache: "no-store" },
    );
    sourceCircuitStates.value = Object.fromEntries(
      (response.data?.sources || [])
        .filter((source) => !!source.id)
        .map((source) => [source.id!, source.health?.circuitState || "closed"]),
    );
  } catch (error: any) {
    sourceCircuitStates.value = {};
    const code = error?.statusCode || error?.response?.status;
    if ([401, 403].includes(code)) {
      adminAuthenticated.value = false;
      adminLocked.value = true;
      return;
    }
    storageError.value = apiErrorMessage(error);
  }
}

let disposed = false;
let activeController: AbortController | undefined;
async function testSource(source: SourceDefinition) {
  if (runningId.value) return;
  if (!keyword.value.trim()) {
    notify("请输入测试关键词。");
    return;
  }
  runningId.value = source.id;
  activeController = new AbortController();
  const timer = setTimeout(() => activeController?.abort(), 16000);
  try {
    const result = await $fetch<SourceProbe>("/api/sources/probe", {
      method: "POST",
      body: { sourceId: source.id, kw: keyword.value.trim() },
      signal: activeController.signal,
      retry: 0,
    });
    if (disposed) return;
    reports.value[source.id] = result;
    notify(`${source.name}：${result.message}`);
  } catch (error: any) {
    if (!disposed) {
      const code = error?.statusCode || error?.response?.status;
      if ([401, 403].includes(code)) { adminAuthenticated.value = false; adminLocked.value = true; }
      notify(
        code === 401
          ? "请先登录管理员账号。"
          : code === 403
            ? "当前账号没有管理员权限。"
            : `管理后台请求未完成：${error?.data?.statusMessage || error.message}。未将其记为来源异常。`,
      );
    }
  } finally {
    clearTimeout(timer);
    runningId.value = "";
    activeController = undefined;
  }
}
async function requestDeleteSource(source: SourceDefinition) {
  if (runningId.value || sourceToggleId.value) {
    notify("请等待当前来源操作完成后再删除。");
    return;
  }
  if (!window.confirm(`确定删除「${source.name}」吗？删除后下一次请求立即停止加载。`)) return;
  try {
    await $fetch(`/api/settings/sources/${encodeURIComponent(source.id)}`, {
      method: "DELETE",
      body: { confirmation: source.id, actor: "admin-console" },
    });
    delete reports.value[source.id];
    detailDrawerOpen.value = false;
    debugDialogOpen.value = false;
    await Promise.all([loadSourceCatalog(), loadSourceHealth()]);
    notify("来源已删除，下一次请求立即生效。");
  } catch (error: any) {
    notify(apiErrorMessage(error));
  }
}
async function copy(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    notify("已复制到剪贴板。");
  } catch {
    notify("无法访问剪贴板，请手动选择并复制。");
  }
}
function closeTopmostOverlay(event: KeyboardEvent) {
  if (event.key !== "Escape") return;
  if (debugDialogOpen.value) debugDialogOpen.value = false;
  else if (detailDrawerOpen.value) detailDrawerOpen.value = false;
}
watch(
  () => detailDrawerOpen.value || debugDialogOpen.value,
  (open) => {
    if (import.meta.client) document.body.style.overflow = open ? "hidden" : "";
  },
);
onMounted(() => window.addEventListener("keydown", closeTopmostOverlay));
onBeforeUnmount(() => {
  window.removeEventListener("keydown", closeTopmostOverlay);
  document.body.style.overflow = "";
  disposed = true;
  activeController?.abort();
  clearTimeout(noticeTimer);
});
</script>

<style src="../../assets/source-console.css"></style>
