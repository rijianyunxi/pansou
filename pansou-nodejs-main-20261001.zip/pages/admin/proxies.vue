<template>
  <AdminProxyNodesPage />
</template>
