import type { SearchResult } from "../types/models";
import { executeSourceTransform } from "./runtime";
import type {
  SourceDefinition,
  SourceExecutionResult,
  SourceExecutionTrace,
  SourceValue,
} from "./types";
import {
  RESERVED_VARIABLES,
  interpolateTemplate,
  validateSourceDefinition,
} from "./validation";
import { executeSafeHttp, type SafeHttpResponse } from "../http/safeHttpExecutor";
import { getUnifiedRequestTimeoutMs } from "../services/timeoutPolicy";
import {
  acquireProxyRequest,
  reportProxyFailure,
  reportProxySuccess,
  type ProxyLease,
} from "../services/proxyPoolService";
import { resolveProxyRoute } from "../services/proxyRoutingService";
import {
  REDACTED,
  isSensitiveKey,
  redactSensitiveValue,
} from "../utils/redaction";

const DEFAULT_MAX_REQUEST_BODY_BYTES = 64 * 1024;
const RAW_PREVIEW_LIMIT = 100_000;

const text = (value: unknown): string =>
  value == null ? "" : typeof value === "string" ? value : String(value);

/** Query values may be nested objects; encode them as one JSON query value. */
export function serializeSourceQueryValue(value: SourceValue): string {
  if (value !== null && typeof value === "object") return JSON.stringify(value);
  return text(value);
}

function errorHttpStatus(error: unknown): number | null {
  if (!error || typeof error !== "object") return null;
  const status = Number((error as { statusCode?: unknown }).statusCode);
  return Number.isInteger(status) && status >= 100 && status <= 599 ? status : null;
}


interface RenderedRequest {
  url: URL;
  headers: Record<string, string>;
  body?: string;
  method: "GET" | "POST";
}

function requestDebugSnapshot(
  rawUrl: string,
  rendered: RenderedRequest,
) {
  const url = new URL(rawUrl);
  const query: Record<string, string | string[]> = {};
  for (const key of new Set(url.searchParams.keys())) {
    const values = url.searchParams.getAll(key).map((value) => (
      isSensitiveKey(key) ? REDACTED : value
    ));
    query[key] = values.length > 1 ? values : values[0] || "";
    if (isSensitiveKey(key)) url.searchParams.set(key, REDACTED);
  }
  const headers = Object.fromEntries(Object.entries(rendered.headers).map(([key, value]) => [
    key,
    isSensitiveKey(key) ? REDACTED : value,
  ]));
  let body: unknown = undefined;
  if (rendered.body !== undefined) {
    const contentType = rendered.headers["content-type"] || "";
    try {
      body = contentType.includes("application/json")
        ? JSON.parse(rendered.body)
        : contentType.includes("application/x-www-form-urlencoded")
          ? Object.fromEntries(new URLSearchParams(rendered.body))
          : rendered.body;
    } catch {
      body = rendered.body;
    }
    body = redactSensitiveValue(body);
  }
  return {
    url: url.toString(),
    query,
    headers,
    ...(body !== undefined ? { body } : {}),
  };
}

const JSON_CONTENT_TYPES = ["application/json", "text/json", "application/*+json"];
const HTML_CONTENT_TYPES = ["text/html", "application/xhtml+xml"];

export async function executeSource(
  rawDefinition: SourceDefinition,
  keyword: string,
  options: {
    signal?: AbortSignal;
    limit?: number;
    /** Receives the completed request trace, including failures. */
    onTrace?: (trace: SourceExecutionTrace) => void;
    /** Template values supplied by the caller, e.g. a validated channel. */
    variables?: Record<string, string | number>;
    /** Additional context exposed to the transform without granting network access. */
    context?: Record<string, unknown>;
    /** Reports synchronous transform + output validation time, including failures. */
    onTransformTiming?: (elapsedMs: number) => void;
  } = {}
): Promise<SourceExecutionResult> {
  const definition = validateSourceDefinition(rawDefinition);
  const request = definition.request;
  const response = definition.response;
  // The persisted system setting is the only timeout source. Callers cannot
  // override it through per-request options or source configuration.
  const requestTimeoutMs = getUnifiedRequestTimeoutMs();
  const baseVariables: Record<string, string | number> = {
    keyword,
    limit: options.limit ?? definition.manifest.maxResults,
    ...(options.variables || {}),
  };
  const allowedVariables = new Set([...RESERVED_VARIABLES, ...Object.keys(options.variables || {})]);

  const runtimeVariables = (): Record<string, string | number> => ({ ...baseVariables });

  const buildRendered = (
    spec: {
      method: "GET" | "POST";
      url: string;
      query?: Record<string, SourceValue>;
      headers?: Record<string, string>;
      bodyType?: "json" | "form";
      body?: SourceValue;
    },
    variables: Record<string, string | number>,
    allowedNames: ReadonlySet<string>,
    acceptFor: "json" | "html" | "text"
  ): RenderedRequest => {
    const requestUrl = new URL(interpolateTemplate(spec.url, variables, allowedNames) as string);
    const applyQuery = (requestUrl: URL): void => {
      for (const [key, value] of Object.entries(spec.query || {})) {
        requestUrl.searchParams.set(
          key,
          serializeSourceQueryValue(interpolateTemplate(value, variables, allowedNames))
        );
      }
    };
    applyQuery(requestUrl);
    const headers: Record<string, string> = {
      accept:
        spec.bodyType === "json" || acceptFor === "json"
          ? "application/json"
          : "text/html",
      ...(spec.headers || {}),
    };
    for (const key of Object.keys(headers)) {
      headers[key] = text(interpolateTemplate(headers[key] ?? "", variables, allowedNames));
    }
    let body: string | undefined;
    if (spec.method === "POST" && spec.body !== undefined) {
      const rendered = interpolateTemplate(spec.body, variables, allowedNames);
      if (spec.bodyType === "form") {
        body = new URLSearchParams(rendered as Record<string, string>).toString();
        headers["content-type"] ||= "application/x-www-form-urlencoded";
      } else {
        body = JSON.stringify(rendered);
        headers["content-type"] ||= "application/json";
      }
    }
    return { url: requestUrl, headers, body, method: spec.method };
  };

  const traces: SourceExecutionTrace[] = [];
  const proxyNodes: import("../types/models").ProxyNodeMeta[] = [];
  const recordProxyNode = (options: {
    nodeId: string;
    nodeName: string;
    status: "success" | "failed";
    httpStatus: number | null;
    elapsedMs: number;
    error?: string;
  }): void => {
    proxyNodes.push({
      ...options,
      attempt: proxyNodes.length + 1,
      ...(options.error ? { error: options.error.slice(0, 500) } : {}),
    });
  };
  const recordTrace = (trace: SourceExecutionTrace): void => {
    traces.push(trace);
    options.onTrace?.(trace);
  };

  // ---- Single request and response transform ----
  const fetchRequest = async (
    rendered: RenderedRequest,
    stage: string,
    format: "json" | "html" | "text"
  ): Promise<SafeHttpResponse> => {
    const started = Date.now();
    const targetUrl = rendered.url.toString();
    const excludedNodeIds = new Set<string>();
    let lastError: unknown;
    const route = resolveProxyRoute(definition.manifest.id);
    const shouldUseProxy = route?.action === "group" && Boolean(route.groupId);
    const proxyGroupId = route?.action === "group" ? route.groupId || undefined : undefined;

    // An unbound source or a direct route does not acquire a lease, but it is
    // still useful to make the transport decision explicit in API metadata.
    for (;;) {
      let lease: ProxyLease | undefined;
      let outboundUrl = targetUrl;
      let directFallback = false;
      const attemptStarted = Date.now();
      try {
        if (shouldUseProxy) {
          try {
            lease = acquireProxyRequest(targetUrl, excludedNodeIds, proxyGroupId);
            outboundUrl = lease.requestUrl;
          } catch (error) {
            if (route?.fallbackAction === "direct") {
              lease = undefined;
              outboundUrl = targetUrl;
              directFallback = true;
            } else {
              throw error;
            }
          }
        }
        const url = outboundUrl;
        const payload = await executeSafeHttp({
          method: rendered.method,
          url,
          headers: rendered.headers,
          body: rendered.body,
          signal: options.signal,
          timeoutMs: requestTimeoutMs,
          maxRequestBodyBytes:
            request.maxRequestBodyBytes ?? DEFAULT_MAX_REQUEST_BODY_BYTES,
          maxResponseBytes: request.maxResponseBytes ?? 2 * 1024 * 1024,
          maxRedirects: 3,
          followRedirects: request.redirect === "follow",
          expectedContentTypes: format === "json"
            ? JSON_CONTENT_TYPES
            : [...HTML_CONTENT_TYPES, "text/plain", "text/markdown"],
          allowedDomains: lease ? [new URL(url).hostname] : request.allowedDomains,
          allowHttp: request.allowInsecureHttp,
        });
        if (lease) {
          const quotaExhausted = payload.response.headers.get("x-proxy-quota") === "exhausted";
          if (quotaExhausted || payload.response.status === 429 || payload.response.status >= 500) {
            recordProxyNode({
              nodeId: lease.nodeId,
              nodeName: lease.nodeName,
              status: "failed",
              httpStatus: payload.response.status,
              elapsedMs: payload.elapsedMs,
              error: quotaExhausted ? "代理节点报告每日额度已用完" : `代理请求返回 HTTP ${payload.response.status}`,
            });
            reportProxyFailure(lease.nodeId, {
              status: payload.response.status,
              message: quotaExhausted ? "代理节点报告每日额度已用完" : `代理请求返回 HTTP ${payload.response.status}`,
              quotaExhausted,
            });
            excludedNodeIds.add(lease.nodeId);
            lastError = new Error(
              quotaExhausted
                ? "代理节点报告每日额度已用完"
                : `代理请求返回 HTTP ${payload.response.status}`,
            );
            recordTrace({
              stage,
              url: payload.url.toString(),
              method: rendered.method,
              status: payload.response.status,
              elapsedMs: payload.elapsedMs,
              bytes: payload.bytes,
              contentType: payload.contentType,
              request: requestDebugSnapshot(outboundUrl, rendered),
              error: lastError.message,
            });
            continue;
          } else {
            // Telegram 的 403/404 仍然是源站响应，不应熔断代理节点。
            reportProxySuccess(lease.nodeId, payload.response.status);
          }
        }
        recordProxyNode({
          nodeId: lease?.nodeId || "direct",
          nodeName: lease?.nodeName || "直连",
          status: "success",
          httpStatus: payload.response.status,
          elapsedMs: payload.elapsedMs,
        });
        recordTrace({
          stage,
          url: payload.url.toString(),
          method: rendered.method,
          status: payload.response.status,
          elapsedMs: payload.elapsedMs,
          bytes: payload.bytes,
          contentType: payload.contentType,
          request: requestDebugSnapshot(url, rendered),
        });
        return payload;
      } catch (error) {
        lastError = error;
        const httpStatus = errorHttpStatus(error);
        if (!lease && (directFallback || (shouldUseProxy && route?.fallbackAction !== "direct"))) {
          throw error;
        }
        if (lease) {
          excludedNodeIds.add(lease.nodeId);
          reportProxyFailure(lease.nodeId, { status: httpStatus, message: error instanceof Error ? error.message : String(error) });
        }
        if (lease || directFallback || !shouldUseProxy) {
          recordProxyNode({
            nodeId: lease?.nodeId || "direct",
            nodeName: lease?.nodeName || "直连",
            status: "failed",
            httpStatus,
            elapsedMs: Date.now() - attemptStarted,
            error: error instanceof Error ? error.message : String(error),
          });
        }
        recordTrace({
          stage,
          url: outboundUrl,
          method: rendered.method,
          status: httpStatus,
          elapsedMs: Date.now() - attemptStarted,
          bytes: 0,
          request: requestDebugSnapshot(outboundUrl, rendered),
          error: error instanceof Error ? error.message : String(error),
        });
        if (!shouldUseProxy || directFallback) throw error;
      }

      if (!shouldUseProxy || directFallback) {
        throw lastError;
      }
    }
  };


  // ---- Single main request and response transform ----
  const rendered = buildRendered(request, runtimeVariables(), allowedVariables, response.format);
  const payload = await fetchRequest(rendered, "request", response.format);
  const raw = payload.body.slice(0, RAW_PREVIEW_LIMIT);
  const rawTruncated = payload.body.length > RAW_PREVIEW_LIMIT;
  const transformStarted = Date.now();
  try {
    const results = executeSourceTransform({
      id: definition.manifest.id,
      version: definition.manifest.version,
      format: response.format,
      // The transform runtime reads the same persisted timeout as the request.
      maxResults: Math.min(Math.max(definition.manifest.maxResults, 1), 500),
      code: response.transform,
    }, payload.body, {
      rawBody: payload.body,
      format: response.format,
      source: definition.manifest.id,
      keyword,
      url: payload.url.toString(),
      ...(options.context || {}),
    }).slice(0, definition.manifest.maxResults);

    return { results, traces, proxyNodes, raw, rawTruncated };
  } finally {
    options.onTransformTiming?.(Date.now() - transformStarted);
  }
}
